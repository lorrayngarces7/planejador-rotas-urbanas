
<?php
$origem = $_POST["origem"];
$destino = $_POST["destino"];
$criterio = $_POST["criterio"];

echo "<h1>Rota buscada de $origem até $destino</h1>";
echo "<p>Critério: $criterio</p>";

// Aqui você pode conectar ao Python via subprocesso ou API no futuro
echo "<p>🚧 Simulação: algoritmo executado no backend (ex: Dijkstra)</p>";
?>
