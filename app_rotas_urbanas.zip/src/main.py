
import heapq
import json

def carregar_grafo(caminho_arquivo):
    with open(caminho_arquivo, 'r') as f:
        return json.load(f)

def dijkstra(grafo, origem, destino):
    fila = [(0, origem, [])]
    visitados = set()

    while fila:
        (custo, no_atual, caminho) = heapq.heappop(fila)

        if no_atual in visitados:
            continue

        caminho = caminho + [no_atual]
        visitados.add(no_atual)

        if no_atual == destino:
            return caminho, custo

        for vizinho, peso in grafo.get(no_atual, {}).items():
            if vizinho not in visitados:
                heapq.heappush(fila, (custo + peso, vizinho, caminho))

    return None, float('inf')

if __name__ == "__main__":
    grafo = carregar_grafo("graph_data.json")
    origem = input("Origem: ").strip()
    destino = input("Destino: ").strip()

    rota, custo = dijkstra(grafo, origem, destino)
    if rota:
        print("➡️  Rota encontrada:", " -> ".join(rota))
        print("🕒 Custo total:", custo)
    else:
        print("❌ Rota não encontrada.")
